<?php

namespace Plugin\CrossBorder1\Config\Constant;

class Setting
{
    const YAML_UPLOAD_PATH = __DIR__.'/../../../../../src/Eccube/Resource/locale';
}
